# Sistema Financeiro (PHP OOP + PDO)

## Estrutura

```
public/        <- ÚNICA pasta exposta na web (document root): index.php + assets/
src/           <- classes PHP (autoload PSR-4 "App\"): Controllers, DAO, Models, Core, Utils
views/         <- templates HTML/PHP (não são classes, por isso ficam FORA do src/)
config/        <- config.php (banco) e routes.php (rotas)
database/      <- schema.sql e dumps
bin/           <- scripts de linha de comando
```

Fluxo: `public/index.php` -> Router (`config/routes.php`) -> Controller -> DAO -> View.

## Como rodar

```bash
composer install
composer dump-autoload        # se já tinha vendor/ (novo autoload de helpers.php)
php bin/create_tables.php     # cria as tabelas no banco definido em config/config.php
php -S localhost:8000 -t public public/index.php
```

Apache/XAMPP: aponte o DocumentRoot para a pasta `public/` (o `.htaccess` já está lá).
